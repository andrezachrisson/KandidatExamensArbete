#define J00  1.0 
#define J01  12.0 // *         // 0 medium 
#define J02  12.0 // *         // 1 light 
#define J11  10.0 // *         // 2 dark
#define J12  6.0 // *
#define J22  8.0  // *

/*



*/
