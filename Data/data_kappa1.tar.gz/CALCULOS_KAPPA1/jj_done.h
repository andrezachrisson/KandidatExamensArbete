#define J00  1.0 
#define J01  1.0 // *         // 0 medium 
#define J02  1.0 // *        // 1 light 
#define J11  10.0 // *         // 2 dark
#define J12  10.0 // *
#define J22  10.0  // *

/*



*/
